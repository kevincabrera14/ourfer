from django.apps import AppConfig


class OurschoolConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ourschool'
